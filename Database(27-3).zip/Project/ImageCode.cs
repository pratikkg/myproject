﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void saveImage_Click(object sender, EventArgs e)
        {
            byte[] img = null;
            string imgLoc = @"D:\Winform\Images\1.jpg";
            FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            img = br.ReadBytes((int)fs.Length);

            string strCmd = "INSERT INTO imagedata_121657([images]) VALUES( @img)";
            SqlConnection sqlCon = new SqlConnection();
            
            SqlCommand sqlCmd = new SqlCommand(strCmd, sqlCon);
            sqlCmd.Parameters.Add(new SqlParameter("@img", img));
            sqlCon.Open();
            sqlCmd.ExecuteNonQuery();
            sqlCon.Close();
        }

        private void GetImage_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;User ID=sqluser;Password=sqluser");
            connection.Open();
            SqlCommand command1 = new SqlCommand("select images from imagedata_121657 where imageID=2", connection);
            byte[] images = (byte[])command1.ExecuteScalar();
            MemoryStream ms = new MemoryStream(images);
            pictureBox1.Image = Image.FromStream(ms);
            connection.Close();
        }

    }
}
