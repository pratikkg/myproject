Create Table ORSGroup6.ProfilePhoto
(
	imageID int Identity(0,1) Primary Key,
	images image null,
	JobSeekerID int
	)
create procedure ORSGroup6.ProcedureSaveImage
(
@images image,
@jobseekersID int
)
as
insert into  ORSGroup6.ProfilePhoto(images,JobSeekerID)
values(@images,@jobseekersID)
GO

select * from ORSGroup6.JobseekersPersonalDetails

Drop table ORSGroup6.ProfilePhoto

Select * from ORSGroup6.ProfilePhoto

alter  procedure ORSGroup6.ProcGetImage
(@jobseekersID int)
As  
BEGIN
Declare  @jobseekersimage int
if EXISTS (Select * from  ORSGroup6.ProfilePhoto where JobSeekerID=@jobseekersID )  
select images from ORSGroup6.ProfilePhoto where JobSeekerID=@jobseekersID
Else
select images from ORSGroup6.ProfilePhoto  where JobSeekerID=0
END

Drop procedure  ORSGroup6.ProcGetImage

EXec ORSGroup6.ProcGetImage 3