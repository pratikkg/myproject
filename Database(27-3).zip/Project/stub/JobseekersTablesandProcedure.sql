-- JobSeekers Table
-- JobSekkers Login Table
create table ORSGroup6.JobseekersLogin
(
LoginID int identity(1,1) PRIMARY KEY,
EmailAddress varchar(20)UNIQUE,
Password varchar(20),
jobseekerID int 
)

--Jobseekers PersonalDetails 
 create table  ORSGroup6.JobseekersPersonalDetails
 (
JobSeekerID int identity(1,1) PRIMARY KEY,
FirstName Varchar(20),
LastName Varchar(20),
MiddleName varchar(20),
ContactNo bigint,
EmailAddress varchar(50)UNIQUE,
Gender varchar(10),
MarraigeStatus varchar(10),
JobSeekersAddress varchar(50),
DOB DateTime
 )
 --Jonseekers Image table
 Create Table ORSGroup6.ProfilePhoto
(
	imageID int Identity(0,1) Primary Key,
	images image null,
	JobSeekerID int
	)
 --Jobseekers Professtional Details 
 Create Table ORSGroup6.JobSeekerProfessionalDetails
 (
JobSeekerID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID) Unique   ,
CurrentDesignation varchar(20),
PrimarySkills varchar(50),
SecondarySkills varchar(50),
TrainingAttended varchar(30),
Designation varchar(20),
Location varchar(30),
Experience varchar(20),
 )
 select * from ORSGroup6.JobseekersPersonalDetails
 select * from ORSGroup6.JobseekersLogin
 
 --Table for Job seekers Qualification 
 Create Table  ORSGroup6.JobseekersQualificationDetails 
 (
 QualificationID int identity(1,1) Primary key,
 Degree Varchar(20),
 Branch Varchar(20),
 Passingyear int,
 Percentage Decimal,
 UniversityName varchar(20),
 JobseekersID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID)
 )
 -------------------------------------------------------------------------------------------------------------------------------------
-- Procedure to Insert New Jobseeker
Alter Procedure AddJobseekers
(
@FirstName Varchar(20),
@LastName Varchar(20),
@MiddleName varchar(20),
@ContactNo bigint,
@EmailAddress varchar(50),
@Gender varchar(10),
@MarraigeStatus varchar(10),
@JobSeekersAddress varchar(50),
@DOB DateTime,
@Password varchar(20)
)
AS
BEGIN
SET NOCOUNT ON;
if  EXISTS (Select * from  ORSGroup6.JobseekersLogin where EmailAddress=@EmailAddress )  
Begin
Select 1
END
else
Begin
insert into ORSGroup6.JobseekersPersonalDetails Values(@FirstName,@LastName,@MiddleName,@ContactNO,@EmailAddress,@Gender,@MarraigeStatus,@JobSeekersAddress,@DOB)
Insert into ORSGroup6.JobseekersLogin Values(@EmailAddress,@Password,scope_identity())
END
END



 EXEC AddJobseekers 'Riya','sharma','rajesh',7896547859,'riya@gmail.com','Male','Single','Mumbai','02/02/1964','Raj@123'
 EXEC AddJobseekers 'Om','Rao','Rakshit',7896547859,'OM@gmail.com','Male','Single','Chennai','04/21/1964','OM@123'
 EXEC AddJobseekers 'sangita','Dutt','Ramesh',7896547859,'sangita@gmail.com','Female','Single','Pune','02/02/1964','Raj@123'
 EXEC AddJobseekers 'sunita','Dange','Ram',7896547859,'sunita@gmail.com','Female','Single','Delhi','12/24/1999','sunita@123'
  EXEC AddJobseekers 'Sheetal','Dange','Ram',7896547859,'sheetal@gmail.com','Female','Single','Delhi','12/24/1999','sheetal@123'
   EXEC AddJobseekers 'Shee','Dancce','Ram',7896547859,'Shi@gmail.com','Female','Single','Delhi','12/24/1999','sheetal@123'
 
 
 
 
 EXEC EmployeeVerification 'sunita@gmail.com','sun@123'
Drop procedure AddJobseekers
 --Procedure to Check for jobseekersValidation
 alter Procedure EmployeeVerification
 (     @EmailAddress NVARCHAR(20),
      @Password NVARCHAR(20)
)
AS
BEGIN
      SET NOCOUNT ON;
      DECLARE @jobseekerId INT
     
      SELECT @jobseekerId = jobseekerID
      FROM ORSGroup6.JobseekersLogin WHERE EmailAddress = @EmailAddress AND Password = @Password
     
      IF @jobseekerId IS NOT NULL
      BEGIN
            Select * from ORSGroup6.JobseekersPersonalDetails Where jobseekerID=@jobseekerId
           END
           
      ELSE
      BEGIN
            SELECT -2 -- User invalid.
      END
END

--Procedure to add Job seekers Proffessional Details 
alter Procedure AddProfessionaDetailsANDphoto
(
@JobSeekerID int,
@CurrentDesignation varchar(20),
@PrimarySkills varchar(50),
@SecondarySkills varchar(50),
@TrainingAttended varchar(30),
@Designation varchar(20),
@Location varchar(30),
@Experience varchar(20)
)
AS 
Begin
SET NOCOUNT ON;
IF NOT EXISTS (Select * from ORSGroup6.JobSeekerProfessionalDetails where jobseekerId= @jobseekerId)
BEGIN
Insert into ORSGroup6.JobSeekerProfessionalDetails Values(@jobseekerId,@CurrentDesignation,@PrimarySkills,@SecondarySkills,@TrainingAttended,@Designation,@Location,@Experience)
END
ELSE
SELECT 23
END 


EXEC AddProfessionaDetailsANDphoto 1,'Manager','Java','DOTNET','Andriod','Developer','Mumbai','2-3'
EXEC AddProfessionaDetailsANDphoto 2,'Anayst','Oracle','HTML','DOTNET','TeamLead','chennai','0-3'

Drop table ORSGroup6.JobSeekerProfessionalDetails

Select * from ORSGroup6.JobSeekerProfessionalDetails
select * from ORSGroup6.JobseekersQualificationDetails
(
-- Procedure to Add Job sekkers QulaificationDetails 
alter Procedure JobseekersQualificationDetails
(
 @Degree Varchar(20),
 @Branch Varchar(20),
 @Passingyear int,
 @Percentage Decimal,
 @UniversityName varchar(20),
 @JobseekersID int
)
AS 
Begin
SET NOCOUNT ON;
BEGIN
Insert into ORSGroup6.JobseekersQualificationDetails Values(@Degree,@Branch,@Passingyear,@Percentage,@UniversityName,@JobseekersID)
END
END

EXEC JobseekersQualificationDetails 'BE','computers',2014,66.64,'Mumbai',3
EXEC JobseekersQualificationDetails 'SSC',Null,2010,78.24,'Mumbai',3
EXEC JobseekersQualificationDetails 'HSC','',2012,78.65,'Mumbai',3



-- Create Procedure to display data Based on JobseekersId 
Create Procedure DisplayQualification
(
@JobSeeker int
)
AS 
BEGIN 
Select * from ORSGroup6.JobseekersQualificationDetails where JobseekersID = @JobSeeker
END
EXEC DisplayQualification 3

-- create Procedure for Update JobseekersPersonalDetails
Create Procedure UpdatePersonalDetails 
(
@JobSeekerId int,
@FirstName Varchar(20),
@LastName Varchar(20),
@MiddleName varchar(20),
@ContactNo bigint,
@Gender varchar(10),
@MarraigeStatus varchar(10),
@JobSeekersAddress varchar(50),
@DOB Datetime)
AS 
UPDATE ORSGroup6.JobseekersPersonalDetails
SET
FirstName=@FirstName ,
LastName=@LastName ,
MiddleName=@MiddleName ,
ContactNo=@ContactNo,
Gender= @Gender ,
MarraigeStatus=@MarraigeStatus,
JobSeekersAddress=@JobSeekersAddress,
DOB=@DOB
Where JobSeekerID=@JobSeekerId

Exec UpdatePersonalDetails 1,'pranita','Shete','rajesh',1236547896,'Female','Married','mumbai','06/24/1999'
-- Procedure to Update Proffessional Details 
Alter Procedure UpdateProfesionalDetails
(
@jobseekerId int,
@CurrentDesignation varchar(20),
@PrimarySkills varchar(50),
@SecondarySkills varchar(50),
@TrainingAttended varchar(30),
@Designation varchar(20),
@Location varchar(30),
@Experience varchar(20))
As
UPDATE ORSGroup6.JobSeekerProfessionalDetails
SET 
CurrentDesignation=@CurrentDesignation,
PrimarySkills=@PrimarySkills,
SecondarySkills=@SecondarySkills,
TrainingAttended=@TrainingAttended,
Designation=@Designation,
Location=@Location,
Experience=@Experience
where JobSeekerID= @jobseekerId;

EXEC UpdateProfesionalDetails 1 ,'SoftwareEngineer','DOTNET','HTML','DOTNET','TESTER','DELHI','3-4'


























Drop Table ORSGroup6.JobseekersPersonalDetails
Drop Table ORSGroup6.JobSeekerProfessionalDetails