

create table dbo.imagedata_121657
(
	imageID int Identity(1,1) not null,
	images image null
)

select * from imagedata_121657

create proc dbo.ProcedureSaveImage
(
@img image
)
as
insert into  dbo.imagedata_121657(images)
values(@img)
GO

create proc dbo.ProcedureReadImage
(
@imgId int
)
as
select images from dbo.imagedata_121657
where imageID=@imgId
GO

create proc dbo.ProReadAllImageId
as
select images from dbo.imagedata_121657
Go

create proc dbo.ProcedureReadAllImage
as
select images from dbo.imagedata_121657
Go
