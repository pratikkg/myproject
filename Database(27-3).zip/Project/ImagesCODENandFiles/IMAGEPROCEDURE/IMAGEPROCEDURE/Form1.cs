﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
namespace IMAGEPROCEDURE
{
    public partial class Form1 : Form
    {
        SqlConnection sqlcon;

        public Form1()
        {
            InitializeComponent();
        }

        private void save_Click(object sender, EventArgs e)
        {

            byte[] img = null;
            string imgLoc = @"D:\Project\ImagesCODENandFiles\3.jpg";
            FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            img = br.ReadBytes((int)fs.Length);
            string connectionstring = ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString;
            sqlcon = new SqlConnection(connectionstring);
            SqlCommand ImageAdd = new SqlCommand("ORSGroup6.ProcedureSaveImage", sqlcon);
            ImageAdd.CommandType = CommandType.StoredProcedure;
            ImageAdd.Parameters.AddWithValue("@images", img);
            ImageAdd.Parameters.AddWithValue("@jobseekersID",2);

            sqlcon.Open();
            ImageAdd.ExecuteNonQuery();
            sqlcon.Close();
        }

        private void get_Click(object sender, EventArgs e)
        {

            string connectionstring = ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString;
            sqlcon = new SqlConnection(connectionstring);
            sqlcon.Open();
            SqlCommand imageget = new SqlCommand("ORSGroup6.ProcGetImage", sqlcon);
            imageget.CommandType = CommandType.StoredProcedure;
            imageget.Parameters.AddWithValue("@jobseekersID",3);
            byte[] images = (byte[])imageget.ExecuteScalar();
            MemoryStream ms = new MemoryStream(images);
            pictureBox1.Image = Image.FromStream(ms);
            sqlcon.Close();

        }
    }
}
