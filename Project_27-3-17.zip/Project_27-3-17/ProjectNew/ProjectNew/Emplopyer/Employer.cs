﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectNew
{
    public partial class Employer : Form
    {
        public Employer()
        {
            InitializeComponent();
        }

        private void Employeer_Load(object sender, EventArgs e)
        {
            EmployeePanel.Visible = true;
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            //panel4.Visible = false;
        }


        private void LinklblPostNewJob_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            //panel4.Visible = false;
        }
        private void LinklblPostedJobs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
        }

        private void LinklblJobAppliedByJS_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel3.Visible = true;
            panel1.Visible = false;
            panel2.Visible = false;
        }
        private void EmployeePanel_Paint(object sender, PaintEventArgs e)
        {


        }
        private void btnClosePostedJobs_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }

        private void btnCloseJobAppliedByJS_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel3.Visible = false;
        }

        private void btnSubmitJobs_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Job Posted Sucessfully");
        }

        //private void linkLblUpdateDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    panel4.Visible = true;
        //    panel3.Visible = false;
        //    panel1.Visible = false;
        //    panel2.Visible = false;
        //}

        //private void btnUpdateDetails_Click(object sender, EventArgs e)
        //{
        //    panel4.Visible = false;
        //    MessageBox.Show("Details Updated Sucessfully");
        //    panel1.Visible = true;
        //}

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void linkLblLogO_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Are You Sure");
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();
        }

        private void Employer_Activated(object sender, EventArgs e)
        {
            label2000.Text = frmHomePage.Euser;
        }

      
        
    }
}
