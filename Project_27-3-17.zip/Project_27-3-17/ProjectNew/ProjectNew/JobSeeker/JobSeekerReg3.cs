﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectNew
{
    public partial class JobSeekerReg3 : Form
    {
        public JobSeekerReg3()
        {
            InitializeComponent();
        }

        private void btnCvBrowse_Click(object sender, EventArgs e)
        {
            //DialogResult result = openFileDialog1.ShowDialog();
            //if (result == DialogResult.OK) // Test result.
            //{
            //    txtJsResume.Text = System.IO.Path.GetFileName(openFileDialog1.FileName);

            //}
            openFileDialog1.Title = "Open Document";
            openFileDialog1.Filter = "docx files (*.docx)|*.docx";
            if (openFileDialog1.ShowDialog() == DialogResult.OK) // Test result.
            {
                txtJsResume.Text = System.IO.Path.GetFileName(openFileDialog1.FileName);

            }
        }

        private void btnPicBrowse_Click(object sender, EventArgs e)
        {
            //openFileDialog1.Title = "Open Image";
            //openFileDialog1.Filter = "jpg files (*.jpg)|*.jpg";

            //if (openFileDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    picBox.Load(openFileDialog1.FileName);

            //}
            //DialogResult result = openFileDialog2.ShowDialog();
            openFileDialog2.Title = "Open Image";
            openFileDialog2.Filter = "jpg files (*.jpg)|*.jpg";
            if (openFileDialog2.ShowDialog() == DialogResult.OK) // Test result.
            {
                txtJsPhoto.Text = System.IO.Path.GetFileName(openFileDialog2.FileName);

            }
        }

        private void btnJsReg3_Click(object sender, EventArgs e)
        {
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();
        }
    }
}
