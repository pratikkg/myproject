﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectNew
{
    public partial class JobSeeker: Form
    {
        public JobSeeker()
        {
            InitializeComponent();
        }

        private void JobSeeker_Load(object sender, EventArgs e)
        {
            JSPannel.Visible = true;
            label100.Visible = true;
           //label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            //btnPersonalDetail1.Visible = false;
           // btnQualificationDetail.Visible = false;
            btnAppliedDetail.Visible = false;
            btnSearchjob.Visible = false;
            //btnPDUpdate.Visible = false;
            btnQDUpdate.Visible = false;
            panel2.Visible = false;
            pnelAddMore.Visible = false;
           

        }

        private void PDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Visible = true;
            label100.Visible = true;
            // btnPersonalDetail1.Visible = true;
            // btnPDUpdate.Visible = true;
            panel2.Visible = false;
            //label2.Visible = false;
            panel3.Visible = false;
            label3.Visible = false;
            panel4.Visible = false;
            label4.Visible = false;
            pnelAddMore.Visible = false;
        }

        private void QDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel2.Visible = true;
            //label2.Visible = true;
            btnQualificationDetail.Visible= true;
            btnQDUpdate.Visible = true;
            panel1.Visible = false;
            //label100.Visible = false;
            panel3.Visible = false;
            label3.Visible = false;
            panel4.Visible = false;
            label4.Visible = false;
            pnelAddMore.Visible = false;

        }

        private void AppJob_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel3.Visible = true;
            label3.Visible = true;
            btnAppliedDetail.Visible = true;
            panel1.Visible = false;
           // label100.Visible = false;
            panel2.Visible = false;
            //label2.Visible = false;
            panel4.Visible = false;
            label4.Visible = false;
            pnelAddMore.Visible = false;
        }

        private void SearchJob_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel4.Visible = true;
            label4.Visible = true;
            btnSearchjob.Visible = true;
            panel1.Visible = false;
           // label100.Visible = false;
            panel2.Visible = false;
            //label2.Visible = false;
            panel3.Visible = false;
            label3.Visible = false;
            pnelAddMore.Visible = false;
        }

        private void btnSearchjob_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
            panel1.Visible = true;
        }

        private void btnAppliedDetail_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel1.Visible = true;
        }

        private void btnQualificationDetail_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = true;
        }

        private void btnPersonalDetail1_Click(object sender, EventArgs e)
        {
           // panel1.Visible = false;
        }

        private void btnPDUpdate_Click(object sender, EventArgs e)
        {
            //panel1.Visible = false;
            MessageBox.Show("Personal Details Updated Sucessfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {
           // panel2.Visible = false;
            MessageBox.Show("Qualification Details Updated Sucessfully");
        }

        //private void txtJsEmailAdd_TextChanged(object sender, EventArgs e)
        //{

        //}

        //private void label11_Click(object sender, EventArgs e)
        //{

        //}

        //private void panel1_Paint(object sender, PaintEventArgs e)
        //{

        //}

        //private void pnelAddMore_Paint(object sender, PaintEventArgs e)
        //{

        //}

        private void btnAddQD_Click(object sender, EventArgs e)
        {
            pnelAddMore.Visible = true;
        }

        //private void label23_Click(object sender, EventArgs e)
        //{

        //}

        private void btnUpdateAddM_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Details Updated Sucessfully");
            pnelAddMore.Visible = false;
        }

        private void linkLblLogO_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Are You Sure");
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();
        }

        private void JobSeeker_Activated(object sender, EventArgs e)
        {
            label1000.Text = frmHomePage.JSuser;
        }
    }
}
