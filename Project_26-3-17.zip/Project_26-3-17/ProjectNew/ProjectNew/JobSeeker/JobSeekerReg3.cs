﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectNew
{
    public partial class JobSeekerReg3 : Form
    {
        public JobSeekerReg3()
        {
            InitializeComponent();
        }

        private void btnCvBrowse_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                txtJsResume.Text = System.IO.Path.GetFileName(openFileDialog1.FileName);
               
            }
        }

        private void btnPicBrowse_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog2.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                txtJsPhoto.Text = System.IO.Path.GetFileName(openFileDialog2.FileName);
                
            }
        }

        private void btnJsReg3_Click(object sender, EventArgs e)
        {
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();
        }
    }
}
