﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectNew
{
    public partial class JobSeekerReg1 : Form
    {
        public JobSeekerReg1()
        {
            InitializeComponent();
        }

        private void btnJsReg1_Click(object sender, EventArgs e)
        {

            //JobSeekerReg1 frm1 = new JobSeekerReg1();
            JobSeekerReg2 frm = new JobSeekerReg2();
            frm.Visible = true;
            this.Hide();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtJsConfirmPass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
